﻿//Задание 4, уровень 3, лаб 6
using System.Collections.Generic;
using System;
using System.Linq;

class Program1
{
    struct Participant
    {
        public string LastName;
        public double Result;

    }

    static void Main(string[] args)
    {
        Console.Write("Введите название первой команды: ");
        string Club1 = Console.ReadLine();
        Console.Write("Введите название второй команды ");
        string Club2 = Console.ReadLine();
        List<Participant> Club1Points = new List<Participant>();
        List<Participant> Club2Points = new List<Participant>();

        // заполнение участников 1ой команды 
        Club1Points.Add(new Participant { LastName = "Курочкина", Result = 70.4 });
        Club1Points.Add(new Participant { LastName = "Кондратьев ", Result = 50 });
        Club1Points.Add(new Participant { LastName = "Пряников", Result = 56 });

        // Заполнение участников 2ой команды
        Club2Points.Add(new Participant { LastName = "Смирнов", Result = 55 });
        Club2Points.Add(new Participant { LastName = "Козлов", Result = 75 });
        Club2Points.Add(new Participant { LastName = "Морозов", Result = 70 });

        // Объединение результатов двух групп 
        List<Participant> Results = Club1Points.Concat(Club2Points).ToList();


        Results = Results.OrderByDescending(x => x.Result).ToList();

        // Вывод результатов в виде таблицы

        Console.WriteLine(" Место     Фамилия      Результат   Группа ");


        int place = 1; // шаг перехода к следующему в списке 
        foreach (var result in Results) //для каждого элемента result идет проверка в Result 
        {
            string group = Club1Points.Contains(result) ? $"{Club1}" : $"{Club2}";//если элемент из Club1Points, то ставим Club1 , если нет , то Club2 
            Console.WriteLine($"|  {place,-4} | {result.LastName,-13} | {result.Result,-11} | {group,-6} |");// вывод в табличку с выравниванием по левому краю и ограниченной длинной слов 
            place++;
        }


    }
}
