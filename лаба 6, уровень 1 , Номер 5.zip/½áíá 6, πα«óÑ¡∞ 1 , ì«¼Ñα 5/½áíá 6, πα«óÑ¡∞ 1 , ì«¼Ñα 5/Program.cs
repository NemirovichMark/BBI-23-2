﻿using System.Runtime.InteropServices;

struct People
{
    private string familia;
    private int mark;
    private int prop;


    public string Familia => familia;
    public int Mark => mark;
    public int Prop => prop;



    public People(string familia, int mark, int prop)
    {
        this.familia = familia;
        this.mark = mark;
        this.prop = prop;
    }

    public void Printinf()
    {
        Console.WriteLine("Фамилия: {0} \t Оценка {1} \t Пропуски {2} ", Familia, Mark, Prop);
    }
}

class Program
{
    static void Main()
    {
        People[] set = new People[6];
        set[0] = new People("Безруков", 4, 2);
        set[1] = new People("Безногов", 2, 8);
        set[2] = new People("Баабайкин", 0, 6);
        set[3] = new People("Бугайкин", 2, 5);
        set[4] = new People("Левошоловин", 5, 0);
        set[5] = new People("Акипов", 2, 4);

        for (int i = 0; i < set.Length; i++)
        {
            if (set[i].Mark == 2)
            {
                set[i].Printinf();
            }
        }
    }
}