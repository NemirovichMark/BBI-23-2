﻿using System.Runtime.InteropServices;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

struct People
{
    private string familia;
    private double prig1;
    private double prig2;
    private double prig3;


    public string Familia => familia;
    public double Prig1 => prig1;
    public double Prig2 => prig2;
    public double Prig3 => prig3;

    public double BestRes => Math.Max(prig1, Math.Max(prig2, prig3));





    public People(string familia, double prig1, double prig2, double prig3)
    {
        this.familia = familia;
        this.prig1 = prig1;
        this.prig2 = prig2;
        this.prig3 = prig3;


    }

    public void Printinf()
    {
        Console.WriteLine("Фамилия: {0} \t Попытка 1: {1} \t Попытка 2: {2}\t Попытка 3: {3}\t Лучший результат: {4} ", Familia, Prig1, Prig2, Prig3, BestRes);
    }
}
class Program
{
    static void Main()
    {
        People[] set = new People[6];
        set[0] = new People("Безруков", 3.34, 2.25, 3.44);
        set[1] = new People("Безногов", 2.22, 1.88, 2.76);
        set[2] = new People("Бабайкин", 0.99, 3.75, 3.13);
        set[3] = new People("Бугайкин", 2.34, 2.97, 3.12);
        set[4] = new People("Левошоловин", 1.87, 2.13, 1.86);
        set[5] = new People("Акипов", 2.99, 4.01, 3.67);



        set = set.OrderByDescending(m => m.BestRes).ToArray(); //сортировка от большего лучшего результата к меньшему , подключается функция из библеотеки Linq
        foreach (var person in set)
        {
            person.Printinf();
        }
    }
}