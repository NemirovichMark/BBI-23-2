﻿//Задание 3, уровень 2, лаб 6
using System;
using System.Linq;

namespace лаба7
{
    class Program
    {
        struct Vodyanoi
        {
            public string LastName;
            public double[] results;
            public double bestRes;
        }

        static void Main(string[] args)
        {
            Console.Write("Число участников: ");
            int n = int.Parse(Console.ReadLine());
            Vodyanoi[] v = new Vodyanoi[n];
            for (int i = 0; i < n; i++)
            {
                v[i] = new Vodyanoi();
                Console.Write($"Фамилия участника {i + 1}: ");
                v[i].LastName = Console.ReadLine();
                v[i].results = new double[3];
                v[i].bestRes = -1;
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{j + 1} результат {i + 1} участника: ");
                    v[i].results[j] = Convert.ToDouble(Console.ReadLine());
                    if (v[i].results[j] > v[i].bestRes)
                    {
                        v[i].bestRes = v[i].results[j];
                    }
                }
                Console.WriteLine($"Лучший результат {i + 1} участника: {v[i].bestRes}\n");
            }

            v = v.OrderByDescending(m => m.bestRes).ToArray();
            Console.WriteLine("Место\tФамилия\tРезультат");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"{i + 1}\t{v[i].LastName}\t{v[i].bestRes}");
                Console.WriteLine(); // Добавляем пустую строку для ровной таблицы
            }
            Console.ReadLine();
        }
    }
}
