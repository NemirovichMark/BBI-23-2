﻿using System;
struct Sportsmen
{
    public string famile;
    public double rez1, rez2, rez;
    public Sportsmen(string famile1,
    double rezz1, double rezz2)
    {
        famile = famile1;
        rez1 = rezz1;
        rez2 = rezz2;
        rez = rez1 + rez2;
    }

}
class Program
{
    static void Main(string[] args)
    {
        Sportsmen[] sp = new Sportsmen[5];
        sp[0] = new Sportsmen("Пупкин", 6.00, 3.25);
        sp[1] = new Sportsmen("Безруков", 4.25, 6.00);
        sp[2] = new Sportsmen("Гагарин", 5.45, 6.00);
        sp[3] = new Sportsmen("Сквозняков", 3.25, 3.25);
        sp[4] = new Sportsmen("Лисицин", 5.45, 2.25);
        for (int i = 0; i < sp.Length; i++)
        {
            Console.WriteLine("Фамилия {0}\t Результат {1:f2}", sp[i].famile, sp[i].rez);
        }
        for (int i = 0; i < sp.Length - 1; i++)
        {
            double amax = sp[i].rez;
            int imax = i;
            for (int j = i + 1; j < sp.Length; j++)
            {
                if (sp[j].rez > amax)
                {
                    amax = sp[j].rez;
                    imax = j;
                }
            }
            Sportsmen temp;
            temp = sp[imax];
            sp[imax] = sp[i];
            sp[i] = temp;

        }
        Console.WriteLine();
        for (int i = 0; i < sp.Length; i++)
        {
            Console.WriteLine("Фамилия {0} \t Результат {1:f2}", sp[i].famile, sp[i].rez);
        }
    }
}

