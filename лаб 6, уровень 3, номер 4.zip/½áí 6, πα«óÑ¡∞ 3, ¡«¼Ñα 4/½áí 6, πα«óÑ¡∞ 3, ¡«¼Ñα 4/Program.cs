﻿using System.Xml.Linq;

struct People
{
    private string familia;
    private int rez;

    private string club;


    public string Familia => familia;
    public string Club => club;
    public int Rez => rez;



    public People(string club, string familia, int rez)
    {
        this.familia = familia;
        this.club = club;
        this.rez = rez;

    }

    public void PrintInfo()
    {
        Console.WriteLine("Команда: {0} \t Фамилия: {1} \t балл: {2}", Club, Familia, Rez);
    }

}

class Program
{
    static void Main()
    {
        List<People> Club1 = new List<People>();
        List<People> Club2 = new List<People>();
        People[] set = new People[6];
        set[0] = new People("Чак-чак", "Меньшов", 2);
        set[1] = new People("Эчпочмак", "Кукурузников", 5);
        set[2] = new People("Эчпочмак", "Горошкин", 10);
        set[3] = new People("Чак-чак", "Горшков", 5);
        set[4] = new People("Эчпочмак", "Сажик", 2);
        set[5] = new People("Чак-чак", "Кузнечик", 10);

        for (int i = 0; i < set.Length; i++)
        {
            if (set[i].Club == "Чак-чак") { Club1.Add(set[i]); }
            if (set[i].Club == "Эчпочмак") { Club2.Add(set[i]); }
        }
        Club1 = Club1.OrderByDescending(n => n.Rez).ToList();
        foreach (var club1 in Club1) { club1.PrintInfo(); }
        Club2 = Club2.OrderByDescending(m => m.Rez).ToList();
        foreach (var club2 in Club2) { club2.PrintInfo(); }

        Console.WriteLine(" ");
        Console.WriteLine("Я не поняла, что было запрошено в задании поэтому ПЕРЕБДЕЛА ");
        Console.WriteLine(" ");
        Console.WriteLine("Общий отсортированный список :");
        // Объединение результатов двух групп 
        List<People> Results = Club1.Concat(Club2).ToList();


        Results = Results.OrderByDescending(x => x.Rez).ToList();

        foreach (var result in Results) { result.PrintInfo(); }

    }
}